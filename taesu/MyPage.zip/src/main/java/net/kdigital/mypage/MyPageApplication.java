package net.kdigital.mypage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyPageApplication.class, args);
	}

}
