package com.example.demo.prefer;

public class PreferSample {
    
}
